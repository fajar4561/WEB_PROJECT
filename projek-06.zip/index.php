<?php 
echo "<script>location='pelanggan';</script>";
?>